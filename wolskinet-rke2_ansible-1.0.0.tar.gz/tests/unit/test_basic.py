"""Unit tests for wolskinet.rke2_ansible."""


def test_basic() -> None:
    """Dummy unit test that always passes.

    Raises:
        AssertionError: If the assertion fails.
    """
    assert bool(1) is True
