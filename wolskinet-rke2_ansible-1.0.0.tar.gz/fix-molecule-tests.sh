#!/bin/bash
# SPDX-License-Identifier: GPL-3.0-or-later
# Script to apply Molecule test fixes to all roles

set -e

ROLES=(
    "mysql_operator"
    "rancher_install" 
    "minio_install"
    "rook_install"
    "teardown"
    "deploy_rke2"
)

echo "Applying Molecule test fixes to roles..."

for role in "${ROLES[@]}"; do
    echo "Processing role: $role"
    
    # 1. Copy prepare.yml if it doesn't exist
    if [[ ! -f "roles/$role/molecule/default/prepare.yml" ]]; then
        echo "  - Creating prepare.yml"
        cp .github/templates/molecule-prepare.yml "roles/$role/molecule/default/prepare.yml"
    fi
    
    # 2. Update molecule.yml to add test mode variables
    if ! grep -q "test_mode:" "roles/$role/molecule/default/molecule.yml"; then
        echo "  - Adding test mode variables to molecule.yml"
        # Add test mode variables to the group_vars section
        sed -i '/group_vars:/,/^[[:space:]]*[[:alpha:]]/{ 
            /ansible_user:/a\
        test_mode: true\
        skip_binary_installation: true\
        skip_service_management: true\
        skip_firewall_configuration: true\
        skip_networking_configuration: true\
        skip_kubernetes_operations: true\
        skip_external_dependencies: true
        }' "roles/$role/molecule/default/molecule.yml"
    fi
    
    echo "  - Role $role processed"
done

echo "All roles processed! Run individual tests with:"
echo "cd roles/{role_name} && molecule test"